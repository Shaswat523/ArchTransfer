## Arch Test Automation Framework

#### 1. Purpose and Contents

The aim of this test automation framework is providing a one-stop solution for test automation requirements. Targeting to create a hybrid framework with highly reusable modules to enable browser testing using Cucumber BDD.

As a first step, this framework is now having options for UI automation(browser based UI automation). <Br>
More features will be added in the upcoming sprints.
