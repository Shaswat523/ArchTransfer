package arch.auto;

public class App
{
    public static void main( String[] args )
    {
        System.out.println( "Arch Test Automation Framework!" );
    }
}
