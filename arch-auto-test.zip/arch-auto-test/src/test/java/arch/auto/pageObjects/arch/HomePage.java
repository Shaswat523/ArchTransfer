package arch.auto.pageObjects.arch;

import arch.auto.utils.selenium.DriverContext;
import arch.auto.utils.selenium.PageObjectUtil;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

public class HomePage extends PageObjectUtil {
	
    public HomePage() {initialise(this);}
    

}

